<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\crud;


//show data
Route::get('/',[crud::class,'Showindex']);
//insert data
Route::post('/inserData',[crud::class,'InsertData']);

// Delete
Route::get('/delete/{id}',[crud::class,'DeletetData']);

//edituser
Route::get('/edit/{id}',[crud::class,'EditData']);

//update info

Route::post('/update/{id}',[crud::class,'updateData']);