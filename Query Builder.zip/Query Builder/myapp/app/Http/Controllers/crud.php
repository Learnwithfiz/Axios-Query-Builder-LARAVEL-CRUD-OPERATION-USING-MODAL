<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
class crud extends Controller
{
    public function Showindex(){
        $sel = DB::table('student')->select()->get();

        return view('home',compact('sel'));
    }
   //H.W form validation korben
   // Msg gulo display korben
    public function InsertData(Request $req){
      $insert = DB::table('student')->insert([
        'name'=>$req->name,
        'email'=>$req->email,
        'dept'=>$req->dept
      ]);
      if($insert){
        return redirect('/');
      }else{
        return "failed";
      }
    }

    public function DeletetData($id){
      $delete = DB::table('student')->where('id',$id)->delete();
      if($delete){
        return redirect('/');
      }else{
        return "Deleted failed";
      }
  
    }
   

    //edit Info 

    public function EditData($id){
        $user = DB::table('student')->where('id',$id)->first();
        return view('edit',compact('user'));
    }
   
    public function updateData($id,Request $req){
       $update = DB::table('student')->where('id',$id)->update([
        'name'=>$req->name,
        'email'=>$req->email,
        'dept'=>$req->dept
       ]);
       if($update){
        return "update success";
       }else{
        return "failed";
       }
    }


}
