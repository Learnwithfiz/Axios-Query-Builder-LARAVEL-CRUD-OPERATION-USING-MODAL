<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($item->name); ?></td>
        <td><?php echo e($item->email); ?></td>
        <td><?php echo e($item->dept); ?></td>
        <td><button onclick="EditData(<?php echo e($item->id); ?>)"class="btn btn-success">edit</button></td>
        <td><button onclick="DeleteData(<?php echo e($item->id); ?>)" class="btn btn-warning">delete</button></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\Users\User\Desktop\Batch 02 Laravel\axios\crud\resources\views/info.blade.php ENDPATH**/ ?>