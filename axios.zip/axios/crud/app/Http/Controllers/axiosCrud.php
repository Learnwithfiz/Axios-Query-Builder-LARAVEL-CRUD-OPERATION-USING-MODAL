<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
class axiosCrud extends Controller
{
    public function ShowInfo(){
        return view('index');
    }

    public function OnInsert(Request $req){
     $insert = DB::table('axios_curd')->insert([
        'name'=>$req->name,
        'email'=>$req->email,
        'dept'=>$req->dept
     ]);

     if($insert){
        return "data send success";
     }else{
        return "data send failed";
     }
    }

    //OnSelect
    public function OnSelect(){
        $user = DB::table('axios_curd')->select()->get();
        
        return view('info',compact('user'));
    }

    public function ondelete($id){
      $delete = DB::table('axios_curd')
      ->where('id',$id)->delete();
    }

    //OnEdit
    public function OnEdit($id){
        $sel = DB::table('axios_curd')->where('id',$id)->first();
        $arr = array();
        $arr= $sel;
        return json_encode($arr);
    }

    public function OnUpdate($hiddenId,Request $req){
       $update = DB::table('axios_curd')->
       where('id',$hiddenId)->update([
        'name'=>$req->name,
        'email'=>$req->email,
        'dept'=>$req->dept
       ]);
    }
}
