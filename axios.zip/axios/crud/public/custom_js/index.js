function AddStudent(){
  var name = document.getElementById("name").value ;
  var email = document.getElementById("email").value ;
  var dept = document.getElementById("dept").value ;
  var url = "/OnInsert";
  var data = {
    name:name,
    email:email,
    dept:dept
  }
  axios.post(url,data)
  .then(function (response) {
    
    OnShow()
  })
  .catch(function (error) {
    // handle error
    console.log(error);
  })
}

window.addEventListener('load',()=>{
    var url = "/OnSelect";
    axios.get(url)
    .then(function (response) {
      document.getElementById("output").innerHTML = response.data
    })
    .catch(function (error) {
      // handle error
      console.log(error);
    })
});


function OnShow(){
    var url = "/OnSelect";
    axios.get(url)
    .then(function (response) {
      document.getElementById("output").innerHTML = response.data
    })
    .catch(function (error) {
      // handle error
      console.log(error);
    }) 
}

//delete data
function DeleteData(id){
   var url = "/delete/"+id;
   axios.get(url)
   .then(function (response) {
    OnShow()
   })
   .catch(function (error) {
     // handle error
     console.log(error);
   }) 
}

// edit data
function EditData(id){

    var hiddenId = $("#hiddenId").val(id)
 $("#EditModal").modal('show');
 var url = "/edit/"+id;
 axios.get(url)
 .then(function (response) {
      var mydata = response.data ;
      $("#name1").val(mydata.name);
      $("#email1").val(mydata.email);
      $("#dept1").val(mydata.dept);
 })
 .catch(function (error) {
   // handle error
   console.log(error);
 }) 
}

function update(){
    var hiddenId = $("#hiddenId").val()
    var name = document.getElementById("name1").value ;
    var email = document.getElementById("email1").value ;
    var dept = document.getElementById("dept1").value ;
    var url = "/update/"+hiddenId;
    var data = {
      name:name,
      email:email,
      dept:dept
    }
    axios.post(url,data)
    .then(function (response) {
      
      OnShow()
    })
    .catch(function (error) {
      // handle error
      console.log(error);
    })
}