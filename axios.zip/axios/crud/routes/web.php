<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\axiosCrud;


Route::get('/',[axiosCrud::class,'ShowInfo']);
//insert 
Route::post('/OnInsert',[axiosCrud::class,'OnInsert']);
///OnSelect
Route::get('/OnSelect',[axiosCrud::class,'OnSelect']);
//delete  
Route::get('/delete/{id}',[axiosCrud::class,'ondelete']);

//data show for edit 
Route::get('/edit/{id}',[axiosCrud::class,'OnEdit']);

///update/
Route::post('/update/{hiddenId}',[axiosCrud::class,'OnUpdate']);
